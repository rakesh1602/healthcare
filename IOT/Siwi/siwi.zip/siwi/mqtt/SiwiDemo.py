import paho.mqtt.publish as publish
import json
import time

# Read data from JSON file
with open('json-files/mqttdata.json') as f:
    data = json.load(f)
    print(data)

# Create ThingsBoard message payload
payload = {
    "ts": int(time.time() * 1000),
    "values": data
}
print(payload)

# Connect to ThingsBoard MQTT broker and publish message
device_id = "fOy0FNdFh8o2hD7hwzeF"
topic = "v1/devices/" + device_id + "/telemetry"
access_token = "fOy0FNdFh8o2hD7hwzeF"
publish.single(topic, payload=json.dumps(payload), hostname="localhost", port=1883, auth={'username': access_token, 'password': ""})
print("message published")
